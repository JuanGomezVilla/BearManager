Iconset: 142 mini country flags (https://www.iconfinder.com/iconsets/142-mini-country-flags-16x16px)
Author: Yummygum (https://www.iconfinder.com/yummygum)
License: Free for commercial use ()
Download date: 2023-05-31